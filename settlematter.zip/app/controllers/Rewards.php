<?php
class Rewards extends Controller{
    

    
    public function __construct(){

    }

    public function index(){
        
     
          // Load View
          $this->view('reward/index');

    }

}