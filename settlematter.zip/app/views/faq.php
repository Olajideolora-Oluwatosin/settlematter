<?php require APPROOT . '/views/components/header.php'; ?>

<!-- Frequently asked question section -->
<section class="faq-section">
    <div class="faq-search">
        <h3>FAQs</h3>
        <input type="text" placeholder="Search FAQs...">


    </div>


    <div class=" mb-10 faq">
        <div>

            <h1 style="color: red;">Page Under Construction</h1>
        </div>
        <!-- <div class="wrap-1">
            <input type="radio" class="input-tabs" id="tab-1" name="tabs">
            <label for="tab-1">
                <div>tab one</div>
                <div class="cross"></div>
            </label>
            <div class="content">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia autem quasi
                inventore
                unde nobis voluptatibus illum quae rerum laudantium minima, excepturi quis maiores. Eaque quae, nam
                delectus
                explicabo, deserunt ipsum!</div>
        </div>

        <div class="wrap-2">
            <input type="radio" class="input-tabs" id="tab-2" name="tabs">
            <label for="tab-2">
                <div>tab two</div>
                <div class="cross"></div>
            </label>
            <div class="content">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia autem quasi
                inventore
                unde nobis voluptatibus illum quae rerum laudantium minima, excepturi quis maiores. Eaque quae, nam
                delectus
                <span class="tip" data-tip="Eaque quae, nam delectus explicabo, deserunt ipsum!">explicabo</span>,
                deserunt ipsum! Lorem ipsum dolor sit amet, consectetur adipisicing elit. <span class="tip"
                    data-tip="Lorem ipsum dolor sit amet, consectetur adipisicing elit.">Mollitia</span> autem quasi
                inventore
                unde nobis voluptatibus illum quae rerum laudantium
                minima, excepturi quis maiores. Eaque quae, nam delectus explicabo, <span class="tip"
                    data-tip="Lorem ipsum dolor sit amet.">deserunt</span> ipsum!
            </div>
        </div>

        <div class="wrap-3">
            <input type="radio" class="input-tabs" id="tab-3" name="tabs">
            <label for="tab-3">
                <div>tab three</div>
                <div class="cross"></div>
            </label>
            <div class="questions">
                <div class="question-wrap">
                    <input type="radio" class="input-tabs" id="question-1" name="question">
                    <label for="question-1">
                        <div>question one</div>
                        <div class="cross"></div>
                    </label>
                    <div class="content">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam atque, soluta doloribus
                        distinctio saepe
                        labore voluptates facere illum alias perferendis praesentium quia vel accusamus incidunt
                        corporis veniam
                        sapiente. Voluptate, quasi.
                    </div>
                </div>
                <div class="question-wrap">
                    <input type="radio" class="input-tabs" id="question-2" name="question">
                    <label for="question-2">
                        <div>question two</div>
                        <div class="cross"></div>
                    </label>
                    <div class="content">
                        Ipsam atque, soluta doloribus distinctio saepe labore voluptates facere illum alias perferendis
                        praesentium quia vel accusamus incidunt corporis veniam sapiente. Voluptate, quasi.
                    </div>
                </div>
            </div>
        </div> -->
    </div>




</section>


<!-- footer -->
<?php require APPROOT . '/views/components/footer.php'; ?>